#include <iostream>
using namespace std;
int main(){
    system("chmod 777 tools.sh");
    system("apt install ruby figlet toilet");
    system("gem install lolcat");
    system("./tools.sh");
}