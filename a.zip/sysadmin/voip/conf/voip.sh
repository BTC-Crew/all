#!/bin/bash

echo '[general]' >> /etc/asterisk/sip.conf
echo 'Port=5060' >> /etc/asterisk/sip.conf
echo 'bindaddr=0.0.0.0' >> /etc/asterisk/sip.conf
echo 'context=other' >> /etc/asterisk/sip.conf


read -p "     MASUKAN NUMBER PHONE    = " number;
read -p "     MASUKAN PASSWORD PHONE  = " pass;


echo '['$number']' >> /etc/asterisk/sip.conf
echo 'type=friend' >> /etc/asterisk/sip.conf
echo 'context=myphones' >> /etc/asterisk/sip.conf
echo 'secret='$pass >> /etc/asterisk/sip.conf
echo 'host=dynamic' >> /etc/asterisk/sip.conf



echo '[other]' >> /etc/asterisk/extensions.conf
echo '[myphones]' >> /etc/asterisk/extensions.conf
echo 'exten => '$number',1,Dial(SIP/'$number')' >> /etc/asterisk/extensions.conf
