#!/bin/bash


read -p "   MASUKAN NAMA DOMAIN     => " domain;
read -p "   NAMA FILE LOKASI DOMAIN => " filedm;
read -p "   MASUKAN IP NET TERBALIK => " ip;
read -p "   NAMA FILE LOKASI DOMAIN => " fileip;


echo '#####################################################################' >> /etc/bind/named.conf.default-zones
echo '' >> /etc/bind/named.conf.default-zones
echo 'zone "'$domain'" {' >> /etc/bind/named.conf.default-zones
echo '      type master;' >> /etc/bind/named.conf.default-zones
echo '      file "/etc/bind/'$filedm'";' >> /etc/bind/named.conf.default-zones
echo '};' >> /etc/bind/named.conf.default-zones
echo "" >> /etc/bind/named.conf.default-zones
echo 'zone "'$ip'.in-addr.arpa" {' >> /etc/bind/named.conf.default-zones
echo '      type master;' >> /etc/bind/named.conf.default-zones
echo '      file "/etc/bind/'$fileip'";' >> /etc/bind/named.conf.default-zones
echo '};' >> /etc/bind/named.conf.default-zones
echo '' >> /etc/bind/named.conf.default-zones
echo '#####################################################################' >> /etc/bind/named.conf.default-zones

echo " "
echo " "
echo " "
echo " "
echo " "



./sysadmin/bind/con.sh
