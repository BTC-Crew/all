#!/bin/bash

mv /etc/proftpd/proftpd.conf /etc/proftpd/proftpd.conf.bc
cp sysadmin/ftp/conf/a.txt /etc/proftpd/proftpd.conf