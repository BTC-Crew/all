#!/bin/bash

apt install ca-certificates apt-transport-https wget curl -y
wget -q https://packages.sury.org/php/apt.gpg -o- 




echo 'deb [trusted=yes] https://packages.sury.org/php/ buster main' >> /etc/apt/sources.list


ls

 apt-key --add apt.gpg
